/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Model.User;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Kayiranga
 */
public class UserDao {

    public UserDao() {
    }
    public boolean checkIfEmailExists(String email) {
    try {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/police_management_system", "root", "");
        PreparedStatement stmt = con.prepareStatement("SELECT * FROM User WHERE email = ?");
        stmt.setString(1, email);
        ResultSet rs = stmt.executeQuery();
        boolean exists = rs.next();
        con.close();
        return exists;
    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}
    public Integer signin(User adduser) {
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/police_management_system", "root", "");
            PreparedStatement stmt = con.prepareStatement("INSERT INTO User(fullname,email,phone,username,password) values(?,?,?,?,?)");

            stmt.setString(1, adduser.getFullname());
            stmt.setString(2, adduser.getEmail());
            stmt.setString(3, adduser.getPhone());
            stmt.setString(4, adduser.getUsername());
            stmt.setString(5, adduser.getPassword());

            int rowAffected = stmt.executeUpdate();

            con.close();
            return rowAffected;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
     public Integer update(User update) {

      try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/police_management_system", "root", "");
            PreparedStatement stmt = con.prepareStatement("UPDATE user SET fullname=?,email=?,phone=? WHERE id=?");
            
            
            stmt.setString(1, update.getFullname());
            stmt.setString(2, update.getEmail());
            stmt.setString(3, update.getPhone());
            stmt.setString(4, update.getId());

             Integer rowAffected = stmt.executeUpdate();

            return rowAffected;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
      public Integer delete(User delete) {

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/police_management_system", "root", "");
            PreparedStatement stmt = con.prepareStatement("DELETE FROM user WHERE id=?");

            stmt.setString(1, delete.getId());
            int rowAffected = stmt.executeUpdate();
            return rowAffected;
        } catch (Exception e) {
            e.printStackTrace();
            // or throw a custom exception with a more descriptive error message
            return -1;
        }
    }
}
