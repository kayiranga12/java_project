/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Model.Criminalinfo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Kayiranga
 */
public class CriminalinfoDao {

    public CriminalinfoDao() {
    }
    public Integer CriminalInfo(Criminalinfo adduser) {
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/police_management_system", "root", "");
            PreparedStatement stmt = con.prepareStatement("INSERT INTO criminalinfo (firstname,lastname,age,gender,father_name,mother_name,district,nationality,phone,martialstatus,dob,nid,casetype,casess,photo) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

            stmt.setString(1, adduser.getFirstName());
            stmt.setString(2, adduser.getLastName());
            stmt.setString(3, adduser.getAge());
            stmt.setString(4, adduser.getGender());
            stmt.setString(5, adduser.getFatherName());
            stmt.setString(6, adduser.getMotherName());
            stmt.setString(7, adduser.getDistrict());
            stmt.setString(8, adduser.getPhone());
            stmt.setString(9, adduser.getMartialStatus());
            stmt.setString(10, adduser.getDob());
            stmt.setString(11, adduser.getNid());
            stmt.setString(12, adduser.getNationality());
            stmt.setString(13, adduser.getCasetype());
            stmt.setString(14, adduser.getCase());
            stmt.setBytes(15, adduser.getPhoto());
            
            

            int rowAffected = stmt.executeUpdate();

            con.close();
            return rowAffected;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
        public Integer update(Criminalinfo update) {

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/police_management_system", "root", "");
            PreparedStatement stmt = con.prepareStatement("UPDATE criminalinfo SET firstname=?,lastname=?,phone=? WHERE id=?");
            
            
            stmt.setString(1, update.getFirstName());
            stmt.setString(2, update.getLastName());
            stmt.setString(3, update.getPhone());
            stmt.setString(4, update.getId());

             Integer rowAffected = stmt.executeUpdate();

            return rowAffected;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
public Integer delete(Criminalinfo delete) {

        try {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/police_management_system", "root", "");
        PreparedStatement stmt = con.prepareStatement("DELETE FROM criminalinfo WHERE id=?");
        
        stmt.setString(1,delete.getId());
        int rowAffected = stmt.executeUpdate();
        return rowAffected;
    } catch (SQLException e) {
        e.printStackTrace();
        // or throw a custom exception with a more descriptive error message
        return -1;
    }
    }

}
