/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Model.Policeinfo;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.*;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author Kayiranga
 */
public class PoliceinfoDao {

   // private Blob photo;

    public PoliceinfoDao() {
    }

    public Integer PoliceInfo(Policeinfo adduser) {
          try {
             Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/police_management_system", "root", "");
            PreparedStatement stmt = con.prepareStatement("INSERT INTO policeinfo (firstname,lastname,age,gender,dob,phone,designation,living,permanent,email,nid,district,jd,rd,policestation,salary,photo) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

            stmt.setString(1, adduser.getFirstName());
            stmt.setString(2, adduser.getLastName());
            stmt.setString(3, adduser.getAge());
            stmt.setString(4, adduser.getGender());
            stmt.setString(5, adduser.getDate());
            stmt.setString(6, adduser.getPhone());
            stmt.setString(7, adduser.getDesignation());
            stmt.setString(8, adduser.getLiving());
            stmt.setString(9, adduser.getPermanent());
            stmt.setString(10, adduser.getEmail());
            stmt.setString(11, adduser.getNID());
            stmt.setString(12, adduser.getDistrict());
            stmt.setString(13, adduser.getPoliceStation());
            stmt.setString(14, adduser.getJd());
            stmt.setString(15, adduser.getRd());
            stmt.setString(16, adduser.getSalary());  
            stmt.setBytes(17, adduser.getPhoto());
            
            int rowAffected = stmt.executeUpdate();

            con.close();
            return rowAffected;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

   public Integer addphoto(Policeinfo addphoto) {
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/police_management_system", "root", "");
            PreparedStatement stmt = con.prepareStatement("SELECT photo FROM policeinfo WHERE id=?");

            // stmt.setString(1, Id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Blob blob = rs.getBlob("photo");
                InputStream inputStream = blob.getBinaryStream();
                BufferedImage image = ImageIO.read(inputStream);

                // Display the image in a JLabel
                ImageIcon icon = new ImageIcon(image);
                JLabel label = new JLabel(icon);
                // Add the label to your GUI
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;

    }

    public Integer update(Policeinfo update) {

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/police_management_system", "root", "");
            PreparedStatement stmt = con.prepareStatement("UPDATE policeinfo SET firstname=?,lastname=?,phone=? WHERE id=?");

            stmt.setString(1, update.getFirstName());
            stmt.setString(2, update.getLastName());
            stmt.setString(3, update.getPhone());
            stmt.setString(4, update.getId());

            Integer rowAffected = stmt.executeUpdate();

            return rowAffected;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public Integer delete(Policeinfo delete) {

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/police_management_system", "root", "");
            PreparedStatement stmt = con.prepareStatement("DELETE FROM policeinfo WHERE id=?");

            stmt.setString(1, delete.getId());
            int rowAffected = stmt.executeUpdate();
            return rowAffected;
        } catch (SQLException e) {
            e.printStackTrace();
            // or throw a custom exception with a more descriptive error message
            return -1;
        }
    }
}
