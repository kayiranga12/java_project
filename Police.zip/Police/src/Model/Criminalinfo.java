/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Kayiranga
 */
public class Criminalinfo {
 private String id;
    private String FirstName;
    private String LastName;
    private String Age;
    private String Gender;
    private String Dob;
    private String Phone;
    private String FatherName;
    private String MotherName;
    private String District;
    private String Nationality;
    private String MartialStatus;
    private String Nid;
   private String Case;
   private String Casetype;
   private byte[] photo;
   
    public Criminalinfo() {
    }

    public Criminalinfo(String id, String FirstName, String LastName, String Age, String Gender, String Dob, String Phone, String FatherName, String MotherName, String District, String Nationality, String MartialStatus, String Nid, String Case, String Casetype, byte[] photo) {
        this.id = id;
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.Age = Age;
        this.Gender = Gender;
        this.Dob = Dob;
        this.Phone = Phone;
        this.FatherName = FatherName;
        this.MotherName = MotherName;
        this.District = District;
        this.Nationality = Nationality;
        this.MartialStatus = MartialStatus;
        this.Nid = Nid;
        this.Case = Case;
        this.Casetype = Casetype;
        this.photo = photo;
    }

    public byte[] getPhoto() {
        return photo;
    }

    public void setPhoto(byte[] photo) {
        this.photo = photo;
    }

    

   

    public String getCase() {
        return Case;
    }

    public void setCase(String Case) {
        this.Case = Case;
    }

   

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCasetype() {
        return Casetype;
    }

    public void setCasetype(String Casetype) {
        this.Casetype = Casetype;
    }


    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public String getAge() {
        return Age;
    }

    public void setAge(String Age) {
        this.Age = Age;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getDob() {
        return Dob;
    }

    public void setDob(String Dob) {
        this.Dob = Dob;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String Phone) {
        this.Phone = Phone;
    }

    public String getFatherName() {
        return FatherName;
    }

    public void setFatherName(String FatherName) {
        this.FatherName = FatherName;
    }

    public String getMotherName() {
        return MotherName;
    }

    public void setMotherName(String MotherName) {
        this.MotherName = MotherName;
    }

    public String getDistrict() {
        return District;
    }

    public void setDistrict(String District) {
        this.District = District;
    }

    public String getNationality() {
        return Nationality;
    }

    public void setNationality(String Nationality) {
        this.Nationality = Nationality;
    }

    public String getMartialStatus() {
        return MartialStatus;
    }

    public void setMartialStatus(String MartialStatus) {
        this.MartialStatus = MartialStatus;
    }

    public String getNid() {
        return Nid;
    }

    public void setNid(String Nid) {
        this.Nid = Nid;
    }
    
}
